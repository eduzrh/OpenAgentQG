import os
import sys
import json
import argparse

# 项目根目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

DATA_ROOT = os.path.join(PROJECT_ROOT, "data")
DATASETS = ["mhqg-wq", "mhqg-pq"]
SPLITS = ["train", "dev", "test"]


def load_jsonl(path):
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def save_jsonl(path, rows):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Prepare unsupervised data layout (input-only + eval_gold)")
    parser.add_argument("--source_dir", type=str, default=None,
                        help="Source data dir (with outSeq). Default: PROJECT_ROOT/../Graph2Seq4KGQG/data")
    parser.add_argument("--data_dir", type=str, default=None,
                        help="Target data dir. Default: OpenAgentQG/data")
    args = parser.parse_args()

    source_dir = args.source_dir or os.path.join(os.path.dirname(PROJECT_ROOT), "Graph2Seq4KGQG", "data")
    data_dir = args.data_dir or DATA_ROOT

    if not os.path.isdir(source_dir):
        print(f"Source not found: {source_dir}")
        print("Use --source_dir to point to Graph2Seq4KGQG/data (or any dir with mhqg-wq/mhqg-pq containing train.json, dev.json, test.json with outSeq).")
        sys.exit(1)

    for dataset in DATASETS:
        src_base = os.path.join(source_dir, dataset)
        tgt_base = os.path.join(data_dir, dataset)
        if not os.path.isdir(src_base):
            print(f"Skip {dataset}: no dir {src_base}")
            continue

        for split in SPLITS:
            src_path = os.path.join(src_base, f"{split}.json")
            if not os.path.isfile(src_path):
                print(f"Skip {dataset}/{split}: no {src_path}")
                continue

            rows = load_jsonl(src_path)
            # 输入仅保留 inGraph + answers + answer_ids + qId，不包含 outSeq（无监督）
            input_only = []
            gold_lines = []
            for r in rows:
                obj = {
                    "qId": r.get("qId"),
                    "answers": r.get("answers", []),
                    "answer_ids": r.get("answer_ids", []),
                    "inGraph": r.get("inGraph", {}),
                }
                input_only.append(obj)
                gold_lines.append((r.get("outSeq") or "").strip())

            out_json = os.path.join(tgt_base, f"{split}.json")
            os.makedirs(tgt_base, exist_ok=True)
            save_jsonl(out_json, input_only)
            print(f"{dataset}/{split}: wrote {len(input_only)} input-only rows -> {out_json}")

            # 金标仅用于评估，写入 eval_gold/<split>.txt（一行一问，与 input 顺序一致）
            eval_gold_dir = os.path.join(tgt_base, "eval_gold")
            os.makedirs(eval_gold_dir, exist_ok=True)
            gold_path = os.path.join(eval_gold_dir, f"{split}.txt")
            with open(gold_path, "w", encoding="utf-8") as f:
                for g in gold_lines:
                    f.write(g + "\n")
            print(f"  -> eval_gold {split}.txt ({len(gold_lines)} lines)")
    print("Done. Use run.py with same data_dir; metrics will use eval_gold/<split>.txt when present.")


if __name__ == "__main__":
    main()
