import os
import sys
import json
import random
import argparse
import shutil

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

DATA_ROOT = os.path.join(PROJECT_ROOT, "data")
BASE_DATASETS = ["mhqg-wq", "mhqg-pq"]
INKG_SUFFIX = "-inkg"
SPLITS = ["train", "dev", "test"]


def collect_edges(adj, edge_types):
    """从 g_adj 收集所有 (s_id, o_id, r_id) 边。"""
    edges = []
    for s_id, neighbors in adj.items():
        for o_id, r_val in neighbors.items():
            r_list = [r_val] if isinstance(r_val, str) else (r_val if isinstance(r_val, list) else [])
            for r_id in r_list:
                r_name = edge_types.get(r_id, r_id)
                if isinstance(r_name, (list, dict)):
                    r_name = r_name[0] if isinstance(r_name, list) else list(r_name.values())[0] if r_name else r_id
                edges.append((s_id, o_id, r_id))
    return edges


def build_adj_from_edges(edges):
    """从边列表重建 g_adj 结构。g_adj[s][o] = [r1, r2, ...]"""
    from collections import defaultdict
    adj = defaultdict(lambda: defaultdict(list))
    for s_id, o_id, r_id in edges:
        if r_id not in adj[s_id][o_id]:
            adj[s_id][o_id].append(r_id)
    return {s: dict(o) for s, o in adj.items()}


def remove_half_edges(inGraph, seed=None):
    """随机删除约 50% 的边，返回新的 inGraph。"""
    adj = inGraph.get("g_adj", {})
    edge_types = inGraph.get("g_edge_types", {})
    names = inGraph.get("g_node_names", {})

    edges = collect_edges(adj, edge_types)
    if len(edges) <= 1:
        return inGraph

    rng = random.Random(seed)
    keep_count = max(1, len(edges) // 2)  # 保留约 50%
    kept = set(rng.sample(range(len(edges)), keep_count))
    new_edges = [edges[i] for i in sorted(kept)]

    new_adj = build_adj_from_edges(new_edges)
    used_nodes = set()
    for s_id, neighbors in new_adj.items():
        used_nodes.add(s_id)
        used_nodes.update(neighbors.keys())
    new_names = {k: v for k, v in names.items() if k in used_nodes}
    new_edge_types = {}
    for s_id, neighbors in new_adj.items():
        for o_id, r_val in neighbors.items():
            r_list = [r_val] if isinstance(r_val, str) else r_val
            for r_id in r_list:
                new_edge_types[r_id] = edge_types.get(r_id, r_id)

    return {
        "g_node_names": new_names,
        "g_edge_types": new_edge_types,
        "g_adj": new_adj,
    }


def load_jsonl(path):
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def save_jsonl(path, rows):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Build IncKG variants (50% triples removed per sample)")
    parser.add_argument("--data_dir", type=str, default=None)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    data_dir = args.data_dir or DATA_ROOT

    for base in BASE_DATASETS:
        src_base = os.path.join(data_dir, base)
        tgt_base = os.path.join(data_dir, base + INKG_SUFFIX)
        if not os.path.isdir(src_base):
            print(f"Skip {base}: no dir {src_base}")
            continue

        for split in SPLITS:
            src_path = os.path.join(src_base, f"{split}.json")
            if not os.path.isfile(src_path):
                print(f"Skip {base}/{split}: no {src_path}")
                continue

            rows = load_jsonl(src_path)
            new_rows = []
            for i, r in enumerate(rows):
                ig = r.get("inGraph", {})
                new_ig = remove_half_edges(ig, seed=args.seed + i)
                new_rows.append({
                    "qId": r.get("qId", i + 1),
                    "answers": r.get("answers", []),
                    "answer_ids": r.get("answer_ids", []),
                    "inGraph": new_ig,
                })
            os.makedirs(tgt_base, exist_ok=True)
            out_path = os.path.join(tgt_base, f"{split}.json")
            save_jsonl(out_path, new_rows)
            print(f"{base}{INKG_SUFFIX}/{split}: {len(new_rows)} samples")

        # 复制 eval_gold、template_library、example_bank（若存在）
        for name in ["eval_gold", "template_library.json", "example_bank.json"]:
            src = os.path.join(src_base, name)
            tgt = os.path.join(tgt_base, name)
            if not os.path.exists(src):
                continue
            if os.path.isdir(src):
                if os.path.isdir(tgt):
                    shutil.rmtree(tgt)
                shutil.copytree(src, tgt)
                print(f"  copied {name}/")
            else:
                shutil.copy2(src, tgt)
                print(f"  copied {name}")
    print("Done. Use --dataset mhqg-wq-inkg or mhqg-pq-inkg with run.py")


if __name__ == "__main__":
    main()
