import os
import sys
import json
import shutil
import argparse

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from data_loader import inGraph_to_triples, triples_to_text

DATA_ROOT = os.path.join(PROJECT_ROOT, "data")
BASE_DATASETS = ["mhqg-wq", "mhqg-pq"]
TEXT_SUFFIX = "-text"
SPLITS = ["train", "dev", "test"]


def load_jsonl(path):
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def save_jsonl(path, rows):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Build Text variants (subgraph as text)")
    parser.add_argument("--data_dir", type=str, default=None)
    args = parser.parse_args()
    data_dir = args.data_dir or DATA_ROOT

    for base in BASE_DATASETS:
        src_base = os.path.join(data_dir, base)
        tgt_base = os.path.join(data_dir, base + TEXT_SUFFIX)
        if not os.path.isdir(src_base):
            print(f"Skip {base}: no dir {src_base}")
            continue

        for split in SPLITS:
            src_path = os.path.join(src_base, f"{split}.json")
            if not os.path.isfile(src_path):
                print(f"Skip {base}/{split}: no {src_path}")
                continue

            rows = load_jsonl(src_path)
            new_rows = []
            for i, r in enumerate(rows):
                ig = r.get("inGraph", {})
                triples, _ = inGraph_to_triples(ig)
                in_seq = triples_to_text(triples)
                new_rows.append({
                    "qId": r.get("qId", i + 1),
                    "answers": r.get("answers", []),
                    "answer_ids": r.get("answer_ids", []),
                    "inGraph": ig,
                    "inSeq": in_seq,
                })
            os.makedirs(tgt_base, exist_ok=True)
            out_path = os.path.join(tgt_base, f"{split}.json")
            save_jsonl(out_path, new_rows)
            print(f"{base}{TEXT_SUFFIX}/{split}: {len(new_rows)} samples")

        for name in ["eval_gold", "template_library.json", "example_bank.json"]:
            src = os.path.join(src_base, name)
            tgt = os.path.join(tgt_base, name)
            if not os.path.exists(src):
                continue
            if os.path.isdir(src):
                if os.path.isdir(tgt):
                    shutil.rmtree(tgt)
                shutil.copytree(src, tgt)
                print(f"  copied {name}/")
            elif os.path.isfile(src):
                shutil.copy2(src, tgt)
                print(f"  copied {name}")
    print("Done. Use --dataset mhqg-wq-text or mhqg-pq-text with run.py")


if __name__ == "__main__":
    main()
