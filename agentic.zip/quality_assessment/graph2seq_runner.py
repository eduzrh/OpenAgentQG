import os
import sys
import glob
import yaml


def run_graph2seq_quality_assessment(
    synthetic_data_dir,
    dataset,
    graph2seq_root=None,
    train_val_ratio=1.0,
    return_predictions_path=True,
    original_test_path=None,
    use_rl_config=True,
):

    if graph2seq_root is None:
        try:
            from config import GRAPH2SEQ_ROOT
            graph2seq_root = GRAPH2SEQ_ROOT
        except Exception:
            # 从 OpenAgentQG 根目录：独立项目时为 ../TKGQG/Graph2Seq4TKGQG
            this_file = os.path.abspath(__file__)
            openagent_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(this_file))))
            graph2seq_root = os.path.join(os.path.dirname(openagent_root), "TKGQG", "Graph2Seq4TKGQG")
            if not os.path.isdir(graph2seq_root):
                graph2seq_root = os.path.join(os.path.dirname(openagent_root), "Graph2Seq4TKGQG")

    graph2seq_src = os.path.abspath(os.path.join(graph2seq_root, "src"))
    if not os.path.isfile(os.path.join(graph2seq_src, "core", "model_handler.py")):
        print(f"Graph2Seq core not found under {graph2seq_src}. Skip Quality Assessment.")
        return None
    graph2seq_data = os.path.join(graph2seq_src, "data")
    syn_name = f"{dataset}-synthetic"
    syn_dest = os.path.join(graph2seq_data, syn_name)
    os.makedirs(syn_dest, exist_ok=True)

    import shutil
    for split in ["train", "dev", "test"]:
        src = os.path.join(synthetic_data_dir, f"{split}.json")
        if os.path.isfile(src):
            shutil.copy(src, os.path.join(syn_dest, f"{split}.json"))
    if original_test_path and os.path.isfile(original_test_path):
        shutil.copy(original_test_path, os.path.join(syn_dest, "test.json"))
        print(f"G2S test set: standard QA full set (overwritten) from {original_test_path}")

    if train_val_ratio < 1.0 and 0 < train_val_ratio < 1:
        train_src = os.path.join(syn_dest, "train.json")
        if os.path.isfile(train_src):
            lines = []
            with open(train_src, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        lines.append(line)
            import random
            rng = random.Random(1234)
            rng.shuffle(lines)
            n_train = max(1, int(len(lines) * train_val_ratio))
            with open(train_src, "w", encoding="utf-8") as f:
                for line in lines[:n_train]:
                    f.write(line + "\n")
            with open(os.path.join(syn_dest, "dev.json"), "w", encoding="utf-8") as f:
                for line in lines[n_train:]:
                    f.write(line + "\n")

    # -inkg/-text 使用基础数据集 config（mhqg-wq / mhqg-pq）
    _config_base = dataset.replace("-inkg", "").replace("-text", "")
    config_dir = os.path.join(graph2seq_src, "config", _config_base)
    # 优先使用 RL 配置（NLL + BLEU/ROUGE reward），论文/README 最佳性能
    if use_rl_config:
        base_yml = os.path.join(config_dir, "rl_graph2seq.yml")
        if not os.path.isfile(base_yml):
            base_yml = os.path.join(config_dir, "graph2seq.yml")
        else:
            print("G2S: using rl_graph2seq (NLL+RL) for better metrics.")
    else:
        base_yml = os.path.join(config_dir, "graph2seq.yml")
    if not os.path.isfile(base_yml):
        print(f"Graph2Seq config not found: {base_yml}. Skip Quality Assessment.")
        return None

    with open(base_yml, "r") as f:
        config = yaml.safe_load(f)
    config["trainset"] = f"data/{syn_name}/train.json"
    config["devset"] = f"data/{syn_name}/dev.json"
    config["testset"] = f"data/{syn_name}/test.json"
    config["out_dir"] = (config.get("out_dir") or "out").replace(dataset, syn_name)
    config["saved_vocab_file"] = f"data/{syn_name}/vocab_model_min3"
    # 合成数据从零训练：不用 pretrained，RL 从 epoch 1 开始；从零训练时学习率用 0.001（RL 配置里 1e-5 是微调用）
    config["pretrained"] = None
    if use_rl_config:
        config["learning_rate"] = 0.001
    syn_yml = os.path.join(config_dir, "graph2seq_synthetic.yml")
    with open(syn_yml, "w") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)

    abs_out = os.path.join(graph2seq_src, config.get("out_dir", ""))
    if abs_out and os.path.isdir(abs_out):
        shutil.rmtree(abs_out)

    cwd = os.getcwd()
    # 确保使用 vendor 内的 Graph2Seq core，避免与 OpenAgentQG 的 core 冲突
    openagent_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    for key in list(sys.modules.keys()):
        if key == "core" or key.startswith("core."):
            del sys.modules[key]
    # 把 G2S src 放最前，去掉开头的 '' 与 OpenAgentQG 根，避免 import 到本项目的 core
    _saved_path = list(sys.path)
    _new_path = list(_saved_path)
    while _new_path and _new_path[0] in ("", openagent_root):
        _new_path.pop(0)
    if graph2seq_src in _new_path:
        _new_path.remove(graph2seq_src)
    _new_path.insert(0, graph2seq_src)
    sys.path[:] = _new_path
    os.chdir(graph2seq_src)
    pred_path = None
    try:
        with open(syn_yml, "r") as f:
            cfg = yaml.safe_load(f)
        from core.model_handler import ModelHandler
        handler = ModelHandler(cfg)
        handler.train()
        metrics = handler.test()
        if metrics and return_predictions_path and os.path.isdir(abs_out):
            candidates = glob.glob(os.path.join(abs_out, "beam_*"))
            if candidates:
                pred_path = candidates[0]
        return {
            "metrics": metrics,
            "g2s_out_dir": abs_out,
            "predictions_path": pred_path,
        } if metrics is not None else None
    except Exception as e:
        print("Graph2Seq Quality Assessment error:", e)
        import traceback
        traceback.print_exc()
        return None
    finally:
        os.chdir(cwd)
        sys.path[:] = _saved_path