# Section 3.3.4: Quality Assessment
# - Editor-in-Chief: score + feedback
# - graph2seq_runner: optional G2S-based feedback (train on synthetic, return BLEU/ROUGE)
