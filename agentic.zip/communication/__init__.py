# Section 3.4: Lightweight Adaptive Communication Mechanism
from .protocol import (
    ROLE_CONTEXT,
    GlobalMessagePool,
    PrivateMessagePool,
    structured_output_managing_editor,
    counterpart_awareness_adapt,
    TemplateLibraryProtocol,
    reset_session_pool,
    get_session_pool,
)
__all__ = [
    "ROLE_CONTEXT",
    "GlobalMessagePool",
    "PrivateMessagePool",
    "structured_output_managing_editor",
    "counterpart_awareness_adapt",
    "TemplateLibraryProtocol",
    "reset_session_pool",
    "get_session_pool",
]
