"""
Lightweight adaptive communication (Section 3.4): dual-pool (global + private),
role-specific interfaces, and template library protocol.
"""
import os
import re
import json
import random
import threading
from collections import defaultdict


def _openagent_root():
    """OpenAgentQG project root (parent of agentic/)."""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class GlobalMessagePool:
    """P_global: shared repository for structured messages with topic metadata. Thread-safe for concurrent publish/retrieve."""

    def __init__(self):
        self._messages = []  # list of {msg, topic, sender, timestamp}
        self._lock = threading.Lock()

    def publish(self, msg, topic, sender):
        import time
        with self._lock:
            self._messages.append({"msg": msg, "topic": topic, "sender": sender, "timestamp": time.time()})

    def retrieve(self, topic=None):
        with self._lock:
            msgs = list(self._messages)
        if topic is None:
            return msgs
        return [m for m in msgs if m["topic"] == topic]


class PrivateMessagePool:
    """P_private_k: subscription-based filter over P_global for agent k."""

    def __init__(self, global_pool, subscription_topics):
        self.global_pool = global_pool
        self.subscription_topics = set(subscription_topics or [])
        self._private = []

    def subscribe(self, topics):
        self.subscription_topics.update(topics)

    def fetch(self):
        out = []
        for m in self.global_pool.retrieve():
            if m["topic"] in self.subscription_topics:
                out.append(m)
        return out

    def add(self, msg):
        self._private.append(msg)


# Role context: RC_k = (role_k, expertise_k, constraints_k)
ROLE_CONTEXT = {
    "editor_in_chief": ("Editor-in-Chief", "quality control and final evaluation", "Evaluate QA pairs only; output score 1-5 and brief feedback."),
    "managing_editor": ("Managing Editor", "coordination and role selection", "Output overall objective, format requirements, and logic requirements only."),
    "contributor": ("Contributor", "draft question generation", "Generate one natural language question that elicits the given answer from the subgraph."),
    "content_editor": ("Content Editor", "content and logic revision", "Suggest revisions for clarity and consistency with the answer and subgraph."),
    "copy_editor": ("Copy Editor", "grammar and style", "Fix grammar, punctuation, and style only."),
}


def structured_output_managing_editor(objective, format_req, logic_req):
    """O_manage = (O_obj, O_format, O_logic)."""
    return {"Oobj": objective, "Oformat": format_req, "Ologic": logic_req}


def counterpart_awareness_adapt(role_from, role_to, g_sub_summary):
    """
    CA_i→j = f_adapt(RC_i, RC_j, G_sub): adapt communication content based on both roles and subgraph context.
    Returns a short string to prepend to prompts: "You are collaborating with X. X's role: ..."
    """
    rc_from = ROLE_CONTEXT.get(role_from, ("", "", ""))
    rc_to = ROLE_CONTEXT.get(role_to, ("", "", ""))
    role_from_name, expertise_from, _ = rc_from
    role_to_name, expertise_to, _ = rc_to
    parts = [f"You are {role_to_name} (expertise: {expertise_to})."]
    if role_from_name:
        parts.append(f"You are revising/coordinating with {role_from_name} (expertise: {expertise_from}).")
    if g_sub_summary and len(g_sub_summary) > 10:
        parts.append(f"Subgraph context: {g_sub_summary[:200]}...")
    return " ".join(parts) + "\n\n"


# ----- Session-level dual-pool (shared across samples in a run) -----
_session_global_pool = None
_session_pool_lock = threading.Lock()


def reset_session_pool():
    """Reset the session-level global pool at start of each run. Call from run.py."""
    global _session_global_pool
    with _session_pool_lock:
        _session_global_pool = GlobalMessagePool()


def get_session_pool():
    """Get or create the session-level global pool. Thread-safe."""
    global _session_global_pool
    with _session_pool_lock:
        if _session_global_pool is None:
            _session_global_pool = GlobalMessagePool()
        return _session_global_pool


def _create_private_pool_for_role(role_name, topics):
    """Create PrivateMessagePool for role subscribing to topics."""
    return PrivateMessagePool(get_session_pool(), topics)


# ----- Template library protocol -----

def _relation_set_from_triples_text(triples_str):
    """Parse relation set from triples text for similarity retrieval."""
    rels = set()
    for m in re.finditer(r"\([^,]+,\s*([^,]+),\s*[^)]+\)", triples_str):
        rels.add(m.group(1).strip())
    return rels


def _relation_pattern_from_triples_text(triples_str, max_rels=4):
    """从 triples 文本提取关系模式字符串，用于骨架。"""
    rels = list(_relation_set_from_triples_text(triples_str))[:max_rels]
    return " | ".join(rels) if rels else ""


def _question_to_abstract_template(q):
    """Abstract template: keep structure words, replace entities with ..."""
    if not q:
        return ""
    STRUCTURE_WORDS = {
        "what", "which", "who", "where", "when", "how", "the", "that", "of", "is", "are", "to", "for", "in", "on",
        "and", "a", "as", "by", "do", "does", "did", "was", "were", "has", "have", "'s", "?", "what's", "whats",
    }
    words = re.findall(r"\S+", (q or "").strip().lower())
    out = []
    for w in words:
        if w.lower() in STRUCTURE_WORDS or (len(w) <= 2 and not re.sub(r"\W", "", w).isdigit()):
            out.append(w)
        else:
            out.append("...")
    s = " ".join(out)
    while "..." in s and "... ..." in s:
        s = s.replace("... ...", "...")
    return s.strip()


class TemplateLibraryProtocol:
    """
    Template library: abstract patterns + relation->question forms.
    Runtime updates in-memory only, not persisted.
    """

    def __init__(self, data_root=None):
        if data_root is None:
            data_root = os.path.join(_openagent_root(), "data")
        self._data_root = data_root
        self._dataset = None
        self._style_templates = []
        self._question_patterns = []
        self._skeleton_demos = []
        self._style_questions = []
        self._example_entries = []
        self._runtime_templates = []
        self._runtime_skeletons = []

    def load(self, dataset):
        """Load template library for dataset (mhqg-wq / mhqg-pq)."""
        path = os.path.join(self._data_root, dataset, "template_library.json")
        self._dataset = dataset
        self._runtime_templates = []
        self._runtime_skeletons = []
        if not os.path.isfile(path) and ("-inkg" in dataset or "-text" in dataset):
            base = dataset.replace("-inkg", "").replace("-text", "")
            path = os.path.join(self._data_root, base, "template_library.json")
        if not os.path.isfile(path):
            self._style_templates = []
            self._question_patterns = []
            self._skeleton_demos = []
            self._style_questions = []
            self._example_entries = []
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._style_templates = data.get("style_templates", [])
            self._question_patterns = data.get("question_patterns", [])
            self._skeleton_demos = data.get("skeleton_demos", [])
            self._style_questions = data.get("style_questions", [])
            self._example_entries = data.get("example_entries", [])
        except Exception:
            self._style_templates = []
            self._question_patterns = []
            self._skeleton_demos = []
            self._style_questions = []
            self._example_entries = []

    def get_style_questions(self, n=30):
        """Return style list: prefer style_templates + runtime, else style_questions."""
        seen = set()
        out = []
        pool = self._style_templates + self._runtime_templates if self._style_templates or self._runtime_templates else (self._style_questions + [])
        for q in pool:
            q = (q or "").strip()
            if q and q not in seen:
                seen.add(q)
                out.append(q)
                if len(out) >= n:
                    return out
        return out[:n]

    def get_example_entries(self, n=20, triples_str=None):
        """Return example entries. Skeleton or full {triples, answers, question}."""
        if self._skeleton_demos or self._runtime_skeletons:
            pool = self._skeleton_demos + [
                {"relation_pattern": r, "question_form": f, "skeleton": True}
                for r, f in self._runtime_skeletons
            ]
            n = min(n, len(pool))
            if triples_str and pool:
                target_rels = _relation_set_from_triples_text(triples_str)
                if target_rels:
                    scored = []
                    for ex in pool:
                        ex_rels = set((ex.get("relation_pattern") or "").split(" | "))
                        scored.append((len(target_rels & ex_rels), ex))
                    scored.sort(key=lambda x: -x[0])
                    return [ex for _, ex in scored[:n]]
            return random.sample(pool, n)
        pool = self._example_entries + []
        if not pool:
            return []
        n = min(n, len(pool))
        if triples_str:
            target_rels = _relation_set_from_triples_text(triples_str)
            if target_rels:
                scored = []
                for ex in pool:
                    ex_rels = _relation_set_from_triples_text(ex.get("triples", ""))
                    scored.append((len(target_rels & ex_rels), ex))
                scored.sort(key=lambda x: -x[0])
                return [ex for _, ex in scored[:n]]
        return random.sample(pool, n)

    def has_skeleton_only(self):
        """Whether template library has skeleton only (no full examples)."""
        return bool(self._skeleton_demos or self._runtime_skeletons)

    def get_patterns(self):
        """返回模板句式列表（如 which ... that ... ?）。"""
        return list(self._question_patterns)

    def update_runtime(self, question, triples_str, answers_str):
        """Append abstract form at runtime: template + skeleton only."""
        q = (question or "").strip()
        if not q or not triples_str:
            return
        tpl = _question_to_abstract_template(q)
        if tpl:
            self._runtime_templates.append(tpl)
        rel_pat = _relation_pattern_from_triples_text(triples_str)
        if rel_pat and tpl:
            self._runtime_skeletons.append((rel_pat, tpl))

    def save_to_folder(self, folder_path):
        """Save runtime state to folder for next iteration."""
        os.makedirs(folder_path, exist_ok=True)
        path = os.path.join(folder_path, "protocol_dump.json")
        data = {
            "runtime_templates": list(self._runtime_templates),
            "runtime_skeletons": [{"relation_pattern": r, "question_form": f} for r, f in self._runtime_skeletons],
            "dataset": self._dataset,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return path

    def load_runtime_from_folder(self, folder_path, merge=True):
        """Load runtime from folder. merge=True appends to current."""
        path = os.path.join(folder_path, "protocol_dump.json")
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            tpls = data.get("runtime_templates", [])
            skels = data.get("runtime_skeletons", [])
            if merge:
                self._runtime_templates.extend(tpls)
                self._runtime_skeletons.extend([
                    (s.get("relation_pattern", ""), s.get("question_form", ""))
                    for s in skels if isinstance(s, dict)
                ])
            else:
                self._runtime_templates = tpls
                self._runtime_skeletons = [(s.get("relation_pattern", ""), s.get("question_form", "")) for s in skels if isinstance(s, dict)]
            return True
        except Exception:
            return False
