"""
Prompt and template bank for agentic generation (Section 3.3 & 3.4).
Role prompts, few-shot examples, gold templates, style questions, Subgraph/Subquestion prompts.
"""

# --- Prompts for each role ---
PROMPT_MANAGING_EDITOR = """You are the Managing Editor. Given the goal (generate a question for the given answer and subgraph), output exactly three short lines:
1) Overall objective (one sentence)
2) Format requirements (e.g. natural, interrogative)
3) Logic requirements (question must elicit the given answer from the subgraph only)

Fusion graph:
{fusion}

Answer(s) to elicit: {answers}

Output (exactly 3 lines, no numbering):"""

PROMPT_CONTRIBUTOR = """You are the Contributor. This is an inverse QA task: you are given the subgraph and the answer; generate a question such that the (question, subgraph) pair forms a valid QA pair—i.e. given the question and the subgraph, a reasoner can infer exactly the given answer(s). The question must be answerable ONLY from the triples; do not include the answer in the question text. Output only the question, one line.

Fusion graph:
{fusion}

Answer(s): {answers}

Requirements: {requirements}

Your question:"""

PROMPT_CONTENT_EDITOR = """You are the Content Editor. Revise the following draft question so it is consistent with the answer and subgraph. Output only the revised question, one line.

Draft: {draft}

Fusion graph:
{fusion}

Answer(s): {answers}

Revised question:"""

PROMPT_COPY_EDITOR = """You are the Copy Editor. Fix grammar, punctuation, and style of the following question. Output only the corrected question, one line.

Question: {draft}

Corrected question:"""

PROMPT_EDITOR_IN_CHIEF = """You are the Editor-in-Chief. Rate the following QA pair for quality (1-5). Consider: does the question naturally elicit the answer? Is it grounded in the subgraph? Is it fluent?
Output exactly two lines:
1) A single number: 1, 2, 3, 4, or 5
2) One sentence of feedback (or "Accept" if 4 or 5)

Question: {question}
Answer(s): {answers}

Fusion graph (reference):
{fusion}

Your rating (first line number only):"""


# Few-shot examples (mhqg format)
FEW_SHOT_EXAMPLES = [
    {
        "triples": "(Justin Bieber, /people/person/sibling_s, none)\n(none, /people/sibling_relationship/sibling, Jaxon Bieber)",
        "answers": "Jaxon Bieber",
        "question": "What is the name of Justin Bieber's brother?",
    },
    {
        "triples": "(Grand Bahama, /location/location/containedby, Bahamas)\n(Bahamas, /base/biblioness/bibs_location/loc_type, Country)",
        "answers": "Bahamas",
        "question": "What country is the Grand Bahama Island in?",
    },
    {
        "triples": "(none, /sports/sports_team_roster/team, Chicago Bulls)\n(Joakim Noah, /sports/pro_athlete/teams, none)",
        "answers": "Chicago Bulls",
        "question": "Who does Joakim Noah play for?",
    },
    {
        "triples": "(Natalie Portman, /film/actor/film, none)\n(none, /film/performance/character, Padmé Amidala)\n(none, /film/performance/film, Star Wars Episode I: The Phantom Menace)",
        "answers": "Padmé Amidala",
        "question": "What character did Natalie Portman play in Star Wars?",
    },
    {
        "triples": "(Cher, /people/person/children, Elijah Blue Allman)\n(Elijah Blue Allman, /people/person/gender, Male)",
        "answers": "Elijah Blue Allman",
        "question": "What is Cher's son's name?",
    },
]


# 单次生成 + few-shot：三元组+答案 -> 问题，多示例提升问答对齐
PROMPT_ONE_SHOT_NO_EXAMPLES = """Generate exactly one natural language question that can be answered by the given answer(s) using ONLY the following knowledge graph triples. Do not include the answer in the question. Output ONLY the question as a single line of natural English—no placeholders, no entity brackets like entity[...], no JSON, no explanations.

Triples (subject, relation, object):
{triples}

Answer(s) to elicit: {answers}

Your question (one line only):"""

PROMPT_FEW_SHOT_HEAD = """Inverse QA task: you are given a subgraph (triples) and the answer. Generate exactly one question such that (question + subgraph) → answer—i.e. given your question and these triples, a reasoner would infer exactly the given answer(s). Requirements:
1) The question is answerable using ONLY the given triples; the correct answer is one of the given answers.
2) Do not include the answer in the question text.
3) When the triples support it, use specific wording so the question unambiguously targets the answer. Prefer a clear, complete question over a very short one.
Output ONLY the question, one line, natural English—no placeholders, no entity brackets, no JSON.

"""
PROMPT_FEW_SHOT_TAIL = """
Now generate for this input:

Triples (subject, relation, object):
{triples}

Answer(s) to elicit: {answers}

Your question (one line only):"""


# Zero-shot subgraph-only (for Graph2Seq synthetic data)
PROMPT_SUBGRAPH_ONLY_HEAD = """Generate one natural language question that can be answered using ONLY the following knowledge graph triples. Do not include the answer in the question. Use structures like which/that/the when the triples support it. Output ONLY the question, one line, lowercase, end with ' ?'.
"""
PROMPT_SUBGRAPH_ONLY_TAIL = """
Triples (subject, relation, object):
{triples}

Your question (one line only):"""


# ----- 与 gold 一致的模板短语（从 dev 参考中总结）-----
GOLD_TEMPLATES = [
    "which of ... that ... ?",
    "which ... that ... ?",
    "the country that contains ... what ... ?",
    "the ... that ... what ... ?",
    "find the ... that ... , what ... ?",
    "who is the ... that ... ?",
    "what ... of the ... that ... ?",
    "the people from the country that contains ... speak what ... ?",
    "what type of government is used in the country with ... ?",
    "... is the mascot for the team that last won ... when ?",
]


# Style: train only (no dev/test leak)
STYLE_QUESTIONS_ONLY = [
    "what is the name of justin bieber brother ?",
    "what character did natalie portman play in star wars ?",
    "what country is the grand bahama island in ?",
    "who does joakim noah play for ?",
    "which kennedy died first ?",
    "who is the prime minister '' -g of ethiopia ?",
    "what form of government does russia have today ?",
    "what is cher 's son 's name ?",
    "what character did john noble play in lord of the rings ?",
    "who did draco malloy end up marrying ?",
    "what sport do the toronto maple leafs play ?",
    "what is the president of brazil ?",
]


# ----- Subgraph/Subquestion prompts -----
PROMPT_SUBGRAPH_DEMO = """Input: Triples:
(Justin Bieber, /people/person/sibling_s, none)
(none, /people/sibling_relationship/sibling, Jaxon Bieber)
Answer(s): Jaxon Bieber

Subgraph1: (Justin Bieber, /people/person/sibling_s, none)
Subgraph2: (none, /people/sibling_relationship/sibling, Jaxon Bieber)
Subquestion1: person sibling relationship
Subquestion2: What is the name of Justin Bieber's brother ?

---
Input: Triples:
(Grand Bahama, /location/location/containedby, Bahamas)
(Bahamas, /base/biblioness/bibs_location/loc_type, Country)
Answer(s): Bahamas

Subgraph1: (Grand Bahama, /location/location/containedby, Bahamas)
Subgraph2: (Bahamas, /base/biblioness/bibs_location/loc_type, Country)
Subquestion1: location contained by country
Subquestion2: What country is the Grand Bahama Island in ?
"""

PROMPT_SUBGRAPH_HEAD = """Inverse QA task: given triples and answer, generate a question so that (question + subgraph) → answer. For each input, output Subgraph1, Subgraph2, ... (one triple per line), then Subquestion1, Subquestion2, ... where the LAST Subquestion is the full question such that given it and the triples one can infer the given answer(s). Do not include the answer in the question. Use lowercase for the final question and end with ' ?'. Output only the requested lines, no extra text.

"""
PROMPT_SUBGRAPH_TAIL = """
Input: Triples:
{triples}
Answer(s): {answers}

Subgraph1:"""


# Question revision prompt
PROMPT_REVISE = """Revise the following question to: 1) lowercase, 2) end with ' ?', 3) prefer which/that/the where it fits. Output only the revised question, one line.

Question: {question}

Revised question:"""


__all__ = [
    "PROMPT_MANAGING_EDITOR",
    "PROMPT_CONTRIBUTOR",
    "PROMPT_CONTENT_EDITOR",
    "PROMPT_COPY_EDITOR",
    "PROMPT_EDITOR_IN_CHIEF",
    "FEW_SHOT_EXAMPLES",
    "PROMPT_ONE_SHOT_NO_EXAMPLES",
    "PROMPT_FEW_SHOT_HEAD",
    "PROMPT_FEW_SHOT_TAIL",
    "PROMPT_SUBGRAPH_ONLY_HEAD",
    "PROMPT_SUBGRAPH_ONLY_TAIL",
    "GOLD_TEMPLATES",
    "STYLE_QUESTIONS_ONLY",
    "PROMPT_SUBGRAPH_DEMO",
    "PROMPT_SUBGRAPH_HEAD",
    "PROMPT_SUBGRAPH_TAIL",
    "PROMPT_REVISE",
]

