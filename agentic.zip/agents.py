"""
Adaptive agentic fusion graph collaborative generation (OpenAgentQG Stage 2):
roles, collaborative decision, execution, quality assessment.
"""
import os
import re
import random
import json
from data_loader import triples_to_text
from llm_client import chat, embed as llm_embed
from .communication import (
    ROLE_CONTEXT,
    structured_output_managing_editor,
    counterpart_awareness_adapt,
    TemplateLibraryProtocol,
    get_session_pool,
)
from .prompt_bank import (
    PROMPT_MANAGING_EDITOR,
    PROMPT_CONTRIBUTOR,
    PROMPT_CONTENT_EDITOR,
    PROMPT_COPY_EDITOR,
    PROMPT_EDITOR_IN_CHIEF,
    FEW_SHOT_EXAMPLES,
    PROMPT_ONE_SHOT_NO_EXAMPLES,
    PROMPT_FEW_SHOT_HEAD,
    PROMPT_FEW_SHOT_TAIL,
    PROMPT_SUBGRAPH_ONLY_HEAD,
    PROMPT_SUBGRAPH_ONLY_TAIL,
    GOLD_TEMPLATES,
    STYLE_QUESTIONS_ONLY,
    PROMPT_SUBGRAPH_DEMO,
    PROMPT_SUBGRAPH_HEAD,
    PROMPT_SUBGRAPH_TAIL,
    PROMPT_REVISE,
)
from config import (
    QUALITY_ACCEPT_THRESHOLD, MAX_ITERATIONS, FAST_MODE, ONE_SHOT_Q, N_FEW_SHOT, ABLATION_MODE,
    USE_SUBGRAPH_PROMPT, BATCH_QS_PER_CALL, EXAMPLE_BANK_PATH, NUM_EXAMPLES_FROM_BANK,
    USE_SIMILAR_EXAMPLES, DOUBLE_GENERATION, DATA_ROOT,
    TRIPLE_GENERATION, FIVE_WAY_GENERATION, NUM_TRAIN_FULL_IN_PROMPT, NUM_TRAIN_STYLE_QUESTIONS,
    USE_TOP1_SIMILAR_FIRST, NUM_TOP_SIMILAR_FIRST, CLONE_CLOSEST_STRUCTURE, USE_TWO_STAGE_GENERATION, REVISE_QUESTION,
    USE_DENSE_RETRIEVAL,
)


def _fmt_fusion(fusion):
    """Format fusion graph for prompts."""
    lines = ["Triples:", triples_to_text(fusion.get("triples", []))]
    if fusion.get("meta_symbolic_layer"):
        lines.append("Meta patterns: " + "; ".join(fusion["meta_symbolic_layer"]))
    for e in fusion.get("virtual_hyperedges", [])[:3]:
        lines.append("Context: " + e["knowledge"])
    return "\n".join(lines)


def _format_role_context(role_key):
    """Format ROLE_CONTEXT for prompt preamble. Paper 3.4.1 Role Contextualization."""
    rc = ROLE_CONTEXT.get(role_key, ("", "", ""))
    role_name, expertise, constraints = rc
    parts = [f"You are the {role_name}."]
    if expertise:
        parts.append(f"Expertise: {expertise}.")
    if constraints:
        parts.append(f"Constraints: {constraints}")
    return " ".join(parts) + "\n\n"


def _fetch_accepted_qa_from_pool(n=2):
    """Fetch up to n recent accepted QA from session pool for in-context examples. Paper 3.3.4 formula (16)."""
    pool = get_session_pool()
    msgs = pool.retrieve("accepted_qa")
    if not msgs:
        return []
    # Most recent first (by timestamp)
    msgs = sorted(msgs, key=lambda m: m.get("timestamp", 0), reverse=True)
    out = []
    for m in msgs[:n]:
        msg = m.get("msg")
        if isinstance(msg, dict) and msg.get("triples") and msg.get("question"):
            out.append(msg)
    return out

_example_bank_cache = None
_cache_key_for_bank = None  # (dataset,) for multi-dataset cache
_extra_example_bank = []  # extra examples (e.g. G2S refined) for iteration
_template_protocol = None
_current_dataset = "mhqg-wq"


def set_template_protocol(protocol):
    """Set template protocol (loaded by run.py per dataset)."""
    global _template_protocol
    _template_protocol = protocol


def set_current_dataset(dataset):
    """Set current dataset for example_bank and train_embeddings."""
    global _current_dataset, _example_bank_cache, _cache_key_for_bank, _train_embeddings_cache, _cache_key_emb
    _current_dataset = dataset or "mhqg-wq"
    _example_bank_cache = None
    _train_embeddings_cache = None
    _cache_key_emb = None
    _cache_key_for_bank = None


def set_extra_example_bank(records):
    """Inject extra examples (e.g. G2S refined) for few-shot. records: list of {triples, answers, question}."""
    global _extra_example_bank, _example_bank_cache, _cache_key_for_bank
    _extra_example_bank = list(records) if records else []
    _example_bank_cache = None
    _cache_key_for_bank = None


def get_template_protocol():
    return _template_protocol


def _load_example_bank():
    """Load train example_bank for current dataset (train only, no dev/test leak)."""
    global _example_bank_cache, _cache_key_for_bank
    key = (_current_dataset,)
    if _example_bank_cache is not None and _cache_key_for_bank == key:
        return _example_bank_cache
    path = os.path.join(DATA_ROOT, _current_dataset, "example_bank.json")
    if not os.path.isfile(path):
        path = EXAMPLE_BANK_PATH
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                base = json.load(f)
            _cache_key_for_bank = key
        except Exception:
            base = []
    else:
        base = []
    # Merge G2S refined examples
    _example_bank_cache = list(base or []) + list(_extra_example_bank or [])
    return _example_bank_cache


_train_embeddings_cache = None
_cache_key_emb = None


def _load_train_embeddings():
    """Load train_embeddings.json (triple vectors) for dense retrieval."""
    global _train_embeddings_cache, _cache_key_emb
    key = (_current_dataset,)
    if _train_embeddings_cache is not None and _cache_key_emb == key:
        return _train_embeddings_cache
    path = os.path.join(DATA_ROOT, _current_dataset, "train_embeddings.json")
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                _train_embeddings_cache = json.load(f)
            _cache_key_emb = key
        except Exception:
            _train_embeddings_cache = []
    else:
        _train_embeddings_cache = []
    return _train_embeddings_cache


def _cosine_sim(a, b):
    """Cosine similarity; returns 0 if either norm is 0."""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    if na <= 0 or nb <= 0:
        return 0.0
    return dot / (na * nb)


def _get_train_full_examples(n, triples_str_for_retrieval=None):
    """Get full examples from train; prefer dense (triple embedding sim), else relation overlap + triple count."""
    bank = _load_example_bank()
    if not bank:
        return []
    n = min(n, len(bank))
    if not triples_str_for_retrieval:
        return random.sample(bank, n)
    # Dense retrieval
    if USE_DENSE_RETRIEVAL:
        emb_list = _load_train_embeddings()
        if emb_list:
            query_vec = llm_embed(triples_str_for_retrieval.strip())
            if query_vec is not None:
                target_tc = _triple_count(triples_str_for_retrieval)
                scored = []
                for item in emb_list:
                    ex_vec = item.get("embedding")
                    if ex_vec is None:
                        continue
                    sim = _cosine_sim(query_vec, ex_vec)
                    tc_diff = abs(target_tc - _triple_count(item.get("triples", "")))
                    ex = {"triples": item.get("triples", ""), "answers": item.get("answers", ""), "question": item.get("question", "")}
                    scored.append((sim, tc_diff, ex))
                if scored:
                    scored.sort(key=lambda x: (-x[0], x[1]))
                    return [ex for _, _, ex in scored[:n]]
    # Fallback: relation overlap + triple count
    target_rels = _relation_set_from_triples_text(triples_str_for_retrieval)
    target_tc = _triple_count(triples_str_for_retrieval)
    if target_rels:
        scored = []
        for ex in bank:
            ex_rels = _relation_set_from_triples_text(ex.get("triples", ""))
            overlap = len(target_rels & ex_rels)
            tc_diff = abs(target_tc - _triple_count(ex.get("triples", "")))
            scored.append((overlap, tc_diff, ex))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [ex for _, _, ex in scored[:n]]
    return random.sample(bank, n)


def _get_train_style_questions(n):
    """从 train example_bank 取 n 条问句（仅问句），按长度分层抽样。"""
    bank = _load_example_bank()
    if not bank:
        return []
    qs = [((ex.get("question") or "").strip()) for ex in bank if (ex.get("question") or "").strip() and len((ex.get("question") or "").strip()) > 10]
    if not qs:
        return []
    n = min(n, len(qs))
    by_len = sorted(qs, key=len)
    step = max(1, len(by_len) // n)
    return [by_len[i] for i in range(0, len(by_len), step)][:n]


def _relation_set_from_triples_text(triples_str):
    """Parse relation set from triples text for similarity retrieval."""
    rels = set()
    for m in re.finditer(r"\([^,]+,\s*([^,]+),\s*[^)]+\)", triples_str):
        rels.add(m.group(1).strip())
    return rels


def _entities_from_triples_text(triples_str):
    """Parse entity words from triples for coverage scoring."""
    words = set()
    for m in re.finditer(r"\(\s*([^,]+),\s*[^,]+,\s*([^)]+)\s*\)", triples_str):
        s, o = m.group(1).strip(), m.group(2).strip()
        for part in (s, o):
            if part and part.lower() != "none":
                for w in re.findall(r"[a-z0-9]+", part.lower()):
                    if len(w) > 1:
                        words.add(w)
    return words


def _triple_count(triples_str):
    """Count triples in text."""
    return len(re.findall(r"\([^,]+,", triples_str or ""))


def _get_bank_examples(n, triples_str_for_retrieval=None):
    """Get n examples: prefer protocol template library, else example_bank."""
    proto = get_template_protocol()
    if proto is not None:
        exs = proto.get_example_entries(n, triples_str_for_retrieval)
        if exs:
            return exs
    bank = _load_example_bank()
    if not bank:
        return []
    n = min(n, len(bank))
    if triples_str_for_retrieval:
        target_rels = _relation_set_from_triples_text(triples_str_for_retrieval)
        if target_rels:
            scored = []
            for ex in bank:
                ex_rels = _relation_set_from_triples_text(ex.get("triples", ""))
                overlap = len(target_rels & ex_rels)
                scored.append((overlap, ex))
            scored.sort(key=lambda x: -x[0])
            return [ex for _, ex in scored[:n]]
    return random.sample(bank, n)


def _get_style_questions_for_prompt(n=28):
    """Style questions: prefer protocol, else hand-picked + bank."""
    proto = get_template_protocol()
    if proto is not None:
        from_proto = proto.get_style_questions(n)
        if from_proto:
            return from_proto
    seen = set()
    out = []
    for q in STYLE_QUESTIONS_ONLY:
        q = (q or "").strip()
        if q and q not in seen:
            seen.add(q)
            out.append(q)
    bank = _load_example_bank()
    if bank and len(out) < n:
        by_len = sorted(bank, key=lambda x: len(x.get("question") or ""))
        for step in [0, len(by_len)//3, 2*len(by_len)//3]:
            for ex in by_len[step:step+20]:
                q = (ex.get("question") or "").strip()
                if q and q not in seen and len(q) > 15:
                    seen.add(q)
                    out.append(q)
                    if len(out) >= n:
                        return out
    return out[:n]


def _gold_style_proxy_score(q, triples_str=None, answer_str=None):
    """Proxy score: gold style + entity coverage; penalize if answer appears in question."""
    if not q:
        return 0
    q_lower = q.lower()
    score = (
        len(q_lower)
        + 18 * ("that" in q_lower)
        + 18 * ("which" in q_lower)
        + 10 * ("the " in q_lower)
        + 6 * (" of " in q_lower)
        + 5 * ("what " in q_lower)
        + 3 * ("country" in q_lower)
        + 4 * (q_lower.strip().endswith(" ?"))
    )
    if triples_str:
        entities = _entities_from_triples_text(triples_str)
        if entities:
            covered = sum(1 for e in entities if e in q_lower)
            score += 6 * covered
    return score


def _clean_question(raw):
    """Remove entity[...] placeholders, keep natural language only."""
    if not raw:
        return ""
    # Remove entity[...] placeholders
    raw = re.sub(r"\u4000entity\u4002\[[^\]]*\]", " ", raw, flags=re.IGNORECASE)
    raw = re.sub(r"entity\[[^\]]*\]", " ", raw, flags=re.IGNORECASE)
    # Truncate at remaining entity markers
    for sep in ("entity[", "entity(", "\u4000entity", "entity\u4002"):
        if sep in raw:
            idx = raw.find(sep)
            before = raw[:idx].strip()
            if len(before) > 10 and "?" in before:
                raw = before
            else:
                raw = raw.replace(sep, " ").replace("]", " ").replace(")", " ")
    raw = raw.strip().split("\n")[0].strip()
    return _normalize_for_gold(raw)


def _normalize_for_gold(question):
    """与 gold 格式对齐：小写、结尾 ' ?'，去除模型常见前缀，提升与参考的 n-gram 重叠。"""
    if not question:
        return ""
    q = question.strip().lower()
    if not q:
        return ""
    for prefix in ("** ", "**", "question 1: ", "question 2: ", "question 3: ", "question 4: ", "question 5: ", "1. ", "2. ", "3. "):
        if q.startswith(prefix):
            q = q[len(prefix):].strip()
    q = q.rstrip("? \t")
    return (q + " ?").strip() if q else ""


def normalize_question_for_eval(question):
    """Normalize prediction for eval: lowercase, end with ' ?'."""
    return _normalize_for_gold(question or "")


def _build_few_shot_prompt(triples_str, ans_str):
    """Build prompt with in-context examples (N_FEW_SHOT)."""
    n = min(max(0, N_FEW_SHOT), len(FEW_SHOT_EXAMPLES))
    if n == 0:
        return PROMPT_ONE_SHOT_NO_EXAMPLES.format(triples=triples_str, answers=ans_str)
    parts = [PROMPT_FEW_SHOT_HEAD]
    for ex in FEW_SHOT_EXAMPLES[:n]:
        parts.append("Example:")
        parts.append("Triples:\n" + ex["triples"])
        parts.append("Answer(s): " + ex["answers"])
        parts.append("Question: " + ex["question"])
        parts.append("")
    parts.append(PROMPT_FEW_SHOT_TAIL.format(triples=triples_str, answers=ans_str))
    return "\n".join(parts)


def _extract_final_subquestion(text):
    """从 Subgraph/Subquestion 式输出中提取最后一条 Subquestion 作为最终问题。"""
    if not text:
        return ""
    last_question = ""
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        if re.match(r"Subquestion\d+\s*:", line, re.IGNORECASE):
            last_question = re.sub(r"^Subquestion\d+\s*:\s*", "", line, flags=re.IGNORECASE).strip()
    return _clean_question(last_question) if last_question else _clean_question(text.split("\n")[-1].strip() if text else "")


def _build_subgraph_prompt(triples_str, ans_str):
    """Subgraph + Subquestion single-sample prompt."""
    return PROMPT_SUBGRAPH_HEAD + PROMPT_SUBGRAPH_DEMO + PROMPT_SUBGRAPH_TAIL.format(triples=triples_str, answers=ans_str)


def _build_prompt_head_with_template_protocol(triples_str_for_retrieval, num_fixed_full=5):
    """
    Build prompt head: condensed templates + train examples; top similar first.
    Returns (head_str, use_skeleton) for single/batch prompts.
    """
    proto = get_template_protocol()
    style_list = _get_style_questions_for_prompt(25)
    gold_prepend = [g for g in GOLD_TEMPLATES[:6] if g]
    style_list = gold_prepend + [s for s in style_list if s not in gold_prepend][:16]
    exs = _get_bank_examples(18, triples_str_for_retrieval if USE_SIMILAR_EXAMPLES else None)
    use_skeleton = proto is not None and proto.has_skeleton_only()
    train_full = _get_train_full_examples(NUM_TRAIN_FULL_IN_PROMPT, triples_str_for_retrieval if USE_SIMILAR_EXAMPLES else None)
    top_exs = []
    train_rest = train_full
    if USE_TOP1_SIMILAR_FIRST and train_full and triples_str_for_retrieval:
        n_top = min(max(1, NUM_TOP_SIMILAR_FIRST), len(train_full))
        top_exs = train_full[:n_top]
        train_rest = train_full[n_top:]
    parts = []
    for ex in top_exs:
        parts.append("Closest example (inverse QA: from this question + these triples, the answer follows — generate in the same way):")
        parts.append("Triples:\n" + ex["triples"])
        parts.append("Answer(s): " + ex["answers"])
        parts.append("Question: " + (ex.get("question") or ""))
        parts.append("")
    if top_exs and CLONE_CLOSEST_STRUCTURE and top_exs[0].get("question"):
        parts.append("CRITICAL: Your question MUST use the SAME sentence structure as the Closest example question above (same openings like 'which of the ... for whom ...', same word order and phrasing). Only replace entity/relation names with those from YOUR triples. Do not simplify or rephrase.")
        parts.append("")
    parts.append("Target output style (structures only; fill ... with entities from triples; lowercase, end with ' ?'. Each question must be the one that, together with the triples, uniquely implies the given answer. Prefer which/that/the when triples support comparison or qualification.):")
    parts.append("\n".join(style_list[:18]))
    parts.append("")
    train_style_qs = _get_train_style_questions(NUM_TRAIN_STYLE_QUESTIONS)
    if train_style_qs:
        parts.append("Example questions from same task (match this style exactly):")
        parts.append("\n".join(train_style_qs))
        parts.append("")
    fixed = FEW_SHOT_EXAMPLES[:num_fixed_full]
    parts.append("Full example format (inverse QA: triples + question → answer; one question per example):")
    for ex in fixed:
        parts.append("Triples:\n" + ex["triples"])
        parts.append("Answer(s): " + ex["answers"])
        parts.append("Question: " + ex["question"])
        parts.append("")
    if train_rest:
        parts.append("More task examples (triples -> question, match style above):")
        for ex in train_rest:
            parts.append("Triples:\n" + ex["triples"])
            parts.append("Answer(s): " + ex["answers"])
            parts.append("Question: " + (ex.get("question") or ""))
            parts.append("")
    if use_skeleton and exs:
        parts.append("Additional guidance (relation pattern -> question form):")
        for ex in exs[:10]:
            r = ex.get("relation_pattern", "")
            f = ex.get("question_form", "")
            if r and f:
                parts.append("Relations: " + r)
                parts.append("Form: " + f)
                parts.append("")
    return "\n".join(parts), use_skeleton


def one_shot_generate(fusion, answers):
    """单次调用生成问题；使用凝练模板；可选两阶段（先 plan 再 generate）。"""
    triples_str = triples_to_text(fusion.get("triples", []))
    ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
    plan = ""
    if USE_TWO_STAGE_GENERATION:
        plans = _get_relation_path_plans_batch([(fusion, answers)])
        plan = plans[0] if plans else ""
    bank_head, _ = _build_prompt_head_with_template_protocol(triples_str, num_fixed_full=5)
    bank_head += "Generate one question for:\n\n"
    if USE_SUBGRAPH_PROMPT:
        prompt = bank_head + _build_subgraph_prompt(triples_str, ans_str)
    else:
        prompt = bank_head + PROMPT_FEW_SHOT_TAIL.format(triples=triples_str, answers=ans_str)
    if plan:
        prompt += "\nPlan (use to guide structure): " + plan
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.35)
    if USE_SUBGRAPH_PROMPT:
        question = _extract_final_subquestion(out or "")
    else:
        raw = (out or "").strip().split("\n")[0].strip()
        question = _clean_question(raw)
    proto = get_template_protocol()
    if proto is not None and question:
        proto.update_runtime(question, triples_str, ans_str)
    return question


def generate_question_from_subgraph_only(fusion):
    """Zero-shot: subgraph only (no answer), generate question. For Graph2Seq synthetic data."""
    triples_str = triples_to_text(fusion.get("triples", []))
    head, _ = _build_prompt_head_with_template_protocol(triples_str, num_fixed_full=3)
    prompt = head + "Generate one question for the following triples (no answer given):\n\n" + PROMPT_SUBGRAPH_ONLY_TAIL.format(triples=triples_str)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.25)
    raw = (out or "").strip().split("\n")[0].strip()
    return _clean_question(raw)


def batch_generate_questions_from_subgraph_only(fusions, batch_size=None):
    """Batch subgraph-only generation; returns list of questions."""
    from config import BATCH_QS_PER_CALL
    batch_size = batch_size or BATCH_QS_PER_CALL
    if not fusions:
        return []
    if len(fusions) == 1:
        return [generate_question_from_subgraph_only(fusions[0])]
    k = len(fusions)
    parts = [
        "Generate exactly one natural question per input. Each question must be answerable using ONLY that input's triples (no answer given). Lowercase, end with ' ?'. Output only the questions.",
        "Output format: Question 1: <q> Question 2: <q> ... Question {}: <q>".format(k),
        "",
    ]
    for i, fusion in enumerate(fusions, 1):
        triples_str = triples_to_text(fusion.get("triples", []), max_triples=15)
        parts.append("--- Input {} ---".format(i))
        parts.append("Triples:\n" + triples_str)
        parts.append("")
    parts.append("Output:")
    prompt = "\n".join(parts)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.25)
    return _parse_batch_questions(out or "", k)


def _parse_batch_questions(text, k):
    """Parse Question 1: ... Question 2: ... from batch output."""
    results = [""] * k
    for i in range(1, k + 1):
        pat = re.compile(r"Question\s*" + str(i) + r"\s*[:\-]\s*(.+?)(?=Question\s*\d|$)", re.IGNORECASE | re.DOTALL)
        m = pat.search(text)
        if m:
            results[i - 1] = _clean_question(m.group(1).strip())
    if not any(results):
        lines = [l.strip() for l in text.strip().split("\n") if l.strip()]
        for i, line in enumerate(lines[:k]):
            if line:
                results[i] = _clean_question(line)
    return results


def _get_relation_path_plans_batch(fusions_answers):
    """Stage 2a: one call per k inputs, return relation path + template type plans."""
    k = len(fusions_answers)
    if k == 0:
        return []
    parts = ["Inverse QA: for each input, the question must be such that (question + triples) → answer. Output a one-line plan per input: (1) reasoning path from triples to the answer (which relations lead to the answer); (2) question template type, e.g. which_X_that_Y or what_X_of_Y. Be concise.", ""]
    for i, (fusion, answers) in enumerate(fusions_answers, 1):
        triples_str = triples_to_text(fusion.get("triples", []))
        ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
        parts.append("--- Input {} ---".format(i))
        parts.append("Triples:\n" + triples_str)
        parts.append("Answer(s): " + ans_str)
        parts.append("")
    parts.append("Output format: Plan 1: <line> Plan 2: <line> ... Plan {}: <line>".format(k))
    parts.append("Output:")
    out, _ = chat([{"role": "user", "content": "\n".join(parts)}], temperature=0.1)
    text = (out or "").strip()
    plans = [""] * k
    for m in re.finditer(r"Plan\s*(\d+)\s*:\s*(.+?)(?=\s*Plan\s*\d+\s*:|\s*$)", text, re.DOTALL | re.IGNORECASE):
        idx = int(m.group(1))
        if 1 <= idx <= k:
            plans[idx - 1] = m.group(2).strip()
    return plans


def batch_one_shot_generate(fusions_answers, use_subgraph=USE_SUBGRAPH_PROMPT):
    """Single API call for multiple (fusion, answers); optional two-stage."""
    k = len(fusions_answers)
    if k == 0:
        return []
    if k == 1:
        return [one_shot_generate(fusions_answers[0][0], fusions_answers[0][1])]

    random.seed(42)
    plans = _get_relation_path_plans_batch(fusions_answers) if USE_TWO_STAGE_GENERATION else []
    merged_triples = "\n".join(triples_to_text(fusion.get("triples", [])) for fusion, _ in fusions_answers)
    triples_for_head = triples_to_text(fusions_answers[0][0].get("triples", [])) if k <= 4 else merged_triples
    head_str, use_skeleton = _build_prompt_head_with_template_protocol(triples_for_head, num_fixed_full=5)
    proto = get_template_protocol()
    patterns = (proto.get_patterns()[:12] if proto else []) or GOLD_TEMPLATES[:8]
    instruction = "You are the Contributor (inverse QA task): given triples and answer(s), generate exactly one question per input so that (question + subgraph) → answer. Use the SAME sentence structure as the Closest example(s) above—same openings (e.g. 'which of the ... for whom ...'), same word order. Only entity names come from your triples. Prefer 'which ... that ...', 'what ... of the ...' when triples support it. Lowercase, end with ' ?'."
    if plans:
        instruction += " Use the Plan (relation path / template type) to guide the question structure."
    parts = [
        head_str,
        instruction,
        "Phrase patterns: " + "; ".join(patterns),
        "",
        "CRITICAL: Each output question must be lowercase and end with ' ?'. Output only the questions, no explanation. Generate exactly {} questions.".format(k),
        "Output format: Question 1: <question> Question 2: <question> ... Question {}: <question>".format(k),
        "",
    ]
    for i, (fusion, answers) in enumerate(fusions_answers, 1):
        triples_str = triples_to_text(fusion.get("triples", []))
        ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
        parts.append("--- Input {} ---".format(i))
        parts.append("Triples:\n" + triples_str)
        parts.append("Answer(s): " + ans_str)
        if i <= len(plans) and plans[i - 1]:
            parts.append("Plan: " + plans[i - 1])
        parts.append("")
    parts.append("Output:")
    prompt = "\n".join(parts)
    triples_strs = [triples_to_text(fusions_answers[i][0].get("triples", [])) for i in range(k)]
    answer_strs = [", ".join(fusions_answers[i][1]) if isinstance(fusions_answers[i][1], (list, tuple)) else str(fusions_answers[i][1]) for i in range(k)]
    if FIVE_WAY_GENERATION:
        outs = [chat([{"role": "user", "content": prompt}], temperature=t)[0] or "" for t in (0.15, 0.2, 0.25, 0.3, 0.35)]
        lists = [_parse_batch_questions(o, k) for o in outs]
        results = []
        for i in range(k):
            candidates = [lst[i] for lst in lists if i < len(lst)]
            ts = triples_strs[i] if i < len(triples_strs) else None
            ans = answer_strs[i] if i < len(answer_strs) else None
            best = max(candidates, key=lambda q: _gold_style_proxy_score(q or "", ts, ans)) if candidates else ""
            results.append(best or "")
    elif TRIPLE_GENERATION:
        out1, _ = chat([{"role": "user", "content": prompt}], temperature=0.18)
        out2, _ = chat([{"role": "user", "content": prompt}], temperature=0.24)
        out3, _ = chat([{"role": "user", "content": prompt}], temperature=0.30)
        list1 = _parse_batch_questions(out1 or "", k)
        list2 = _parse_batch_questions(out2 or "", k)
        list3 = _parse_batch_questions(out3 or "", k)
        results = [_pick_best_of_three(list1[i], list2[i], list3[i], triples_strs[i] if i < len(triples_strs) else None, answer_strs[i] if i < len(answer_strs) else None) for i in range(k)]
    elif DOUBLE_GENERATION:
        out1, _ = chat([{"role": "user", "content": prompt}], temperature=0.2)
        out2, _ = chat([{"role": "user", "content": prompt}], temperature=0.35)
        list1 = _parse_batch_questions(out1 or "", k)
        list2 = _parse_batch_questions(out2 or "", k)
        results = [_pick_better(list1[i], list2[i], triples_strs[i] if i < len(triples_strs) else None, answer_strs[i] if i < len(answer_strs) else None) for i in range(k)]
    else:
        out, _ = chat([{"role": "user", "content": prompt}], temperature=0.2)
        results = _parse_batch_questions(out or "", k)
    if REVISE_QUESTION and results:
        results = _revise_questions_batch(results)
    proto = get_template_protocol()
    if proto is not None:
        for i, (fusion, answers) in enumerate(fusions_answers):
            if i < len(results) and results[i]:
                triples_str = triples_to_text(fusion.get("triples", []))
                ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
                proto.update_runtime(results[i], triples_str, ans_str)
    return results


def _pick_better(q1, q2, triples_str=None, answer_str=None):
    """Pick better by style + entity coverage + no-answer-leak proxy score."""
    if not q1:
        return q2 or ""
    if not q2:
        return q1 or ""
    return q1 if _gold_style_proxy_score(q1, triples_str, answer_str) >= _gold_style_proxy_score(q2, triples_str, answer_str) else q2


def _pick_best_of_three(q1, q2, q3, triples_str=None, answer_str=None):
    """Pick best of three by proxy score."""
    best, score = "", -1
    for q in (q1, q2, q3):
        if q:
            s = _gold_style_proxy_score(q, triples_str, answer_str)
            if s > score:
                score = s
                best = q
    return best or (q1 or q2 or q3 or "")


PROMPT_REVISE = """Revise the following question to: 1) lowercase, 2) end with ' ?', 3) prefer which/that/the where it fits. Output only the revised question, one line.

Question: {question}

Revised question:"""


def _revise_question_one(q):
    """Revise single question format/style."""
    if not (q or "").strip():
        return q or ""
    prompt = PROMPT_REVISE.format(question=(q or "").strip())
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.1)
    revised = (out or "").strip().split("\n")[0].strip() if out else ""
    return _normalize_for_gold(revised) if revised else (q or "")


def _revise_questions_batch(questions):
    """Batch revise: one API call, parse by line."""
    if not questions or not REVISE_QUESTION:
        return questions
    k = len(questions)
    prompt = "Revise each question to: 1) lowercase, 2) end with ' ?', 3) prefer which/that/the where it fits. Output exactly {} lines, one revised question per line. No numbering.\n\n".format(k)
    for i, q in enumerate(questions, 1):
        prompt += (q or "").strip() + "\n"
    prompt += "\nRevised (one per line):"
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.1)
    if not out:
        return questions
    lines = [l.strip() for l in out.strip().split("\n") if l.strip()]
    result = []
    for i in range(k):
        result.append(_normalize_for_gold(lines[i]) if i < len(lines) else (questions[i] or ""))
    return result


def managing_editor_decide(fusion, answers):
    """A_manage: produce O_obj, O_format, O_logic. Publish to P_global for downstream agents."""
    fusion_str = _fmt_fusion(fusion)
    ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
    role_pre = _format_role_context("managing_editor")
    prompt = role_pre + PROMPT_MANAGING_EDITOR.format(fusion=fusion_str, answers=ans_str)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.3)
    lines = [l.strip() for l in out.strip().split("\n") if l.strip()]
    obj = lines[0] if len(lines) > 0 else "Generate a question for the answer."
    fmt = lines[1] if len(lines) > 1 else "Natural interrogative."
    logic = lines[2] if len(lines) > 2 else "Question must be answerable from the subgraph."
    req = structured_output_managing_editor(obj, fmt, logic)
    # Publish to P_global for Contributor/Content/Copy to fetch (Paper 3.4.2)
    get_session_pool().publish(req, "requirements", "managing_editor")
    return req


def contributor_generate(fusion, answers, requirements_dict):
    """A_contrib: generate draft question. Fetches accepted_qa from pool for in-context boost."""
    fusion_str = _fmt_fusion(fusion)
    ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
    req_str = "; ".join([str(v) for v in requirements_dict.values()])
    role_pre = _format_role_context("contributor")
    # Inject 1-2 recent accepted QA from pool as few-shot (Paper 3.3.4 formula 16)
    accepted = _fetch_accepted_qa_from_pool(2)
    extra = ""
    if accepted:
        extra = "Recent accepted examples (match this style):\n"
        for ex in accepted:
            t = (ex.get("triples") or "")[:120]
            q = (ex.get("question") or "").strip()
            if q:
                extra += f"  Triples: {t}... | Q: {q}\n"
        extra += "\n"
    prompt = role_pre + extra + PROMPT_CONTRIBUTOR.format(fusion=fusion_str, answers=ans_str, requirements=req_str)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.5)
    return out.strip().split("\n")[0].strip() if out else ""


def content_editor_revise(draft, fusion, answers):
    """A_content: revise draft. Counterpart awareness: revising from Contributor (Paper 3.4.1)."""
    fusion_str = _fmt_fusion(fusion)
    ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
    g_sub = triples_to_text(fusion.get("triples", []))[:200]
    ca = counterpart_awareness_adapt("contributor", "content_editor", g_sub)
    role_pre = _format_role_context("content_editor")
    prompt = role_pre + ca + PROMPT_CONTENT_EDITOR.format(draft=draft, fusion=fusion_str, answers=ans_str)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.3)
    return out.strip().split("\n")[0].strip() if out else draft


def copy_editor_polish(draft):
    """A_copy: grammar/style (paper: low temp for polish)."""
    role_pre = _format_role_context("copy_editor")
    prompt = role_pre + PROMPT_COPY_EDITOR.format(draft=draft)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.2)
    return out.strip().split("\n")[0].strip() if out else draft


def editor_in_chief_assess(question, answers, fusion):
    """A_chief: score 1-5 and feedback. Returns (score_int, feedback_str)."""
    fusion_str = _fmt_fusion(fusion)
    ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
    role_pre = _format_role_context("editor_in_chief")
    prompt = role_pre + PROMPT_EDITOR_IN_CHIEF.format(question=question, answers=ans_str, fusion=fusion_str)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.0)
    lines = [l.strip() for l in out.strip().split("\n") if l.strip()]
    score = 3
    if lines:
        first = lines[0]
        for c in "54321":
            if c in first:
                score = int(c)
                break
    if score < 1 or score > 5:
        score = 3
    feedback = lines[1] if len(lines) > 1 else (lines[0] if lines else "")
    return score, feedback


def _publish_accepted_qa_to_pool(question, answers, fusion):
    """Paper 3.3.4 formula (16): save accepted QA to each role's private pool (P_global topic accepted_qa)."""
    triples_str = triples_to_text(fusion.get("triples", []))
    ans_str = ", ".join(answers) if isinstance(answers, (list, tuple)) else str(answers)
    msg = {"question": question, "answers": ans_str, "triples": triples_str}
    get_session_pool().publish(msg, "accepted_qa", "editor_in_chief")


def agentic_collaborative_generation(fusion, answers, max_iterations=None):
    """
    ONE_SHOT_Q: single generation call. Else full MDP multi-role flow.
    Ablations: no_core_role_mgmt, no_collaborative_decision, no_agentic_execution, no_quality_assessment.
    Returns: (question_str, score, num_iterations).
    """
    answers_list = answers if isinstance(answers, (list, tuple)) else [answers]
    if ONE_SHOT_Q or ABLATION_MODE == "no_agentic_execution":
        question = one_shot_generate(fusion, answers_list)
        return question, 0, 1
    if max_iterations is None:
        max_iterations = 1 if FAST_MODE else MAX_ITERATIONS
    if ABLATION_MODE == "no_collaborative_decision":
        max_iterations = 1
    no_core = ABLATION_MODE == "no_core_role_mgmt"
    if FAST_MODE or no_core:
        requirements = {"Oobj": "Generate a question for the answer.", "Oformat": "Natural interrogative.", "Ologic": "Question must be answerable from the subgraph only."}
    else:
        requirements = managing_editor_decide(fusion, answers_list)
    question = None
    score = 0
    no_quality = ABLATION_MODE == "no_quality_assessment"
    for it in range(max_iterations):
        question = contributor_generate(fusion, answers_list, requirements)
        if not question:
            continue
        question = content_editor_revise(question, fusion, answers_list)
        question = copy_editor_polish(question)
        if no_quality:
            return (question, 0, it + 1)
        score, feedback = editor_in_chief_assess(question, answers_list, fusion)
        if score >= QUALITY_ACCEPT_THRESHOLD:
            # Paper 3.3.4 formula (16): publish to P_global for future in-context use
            _publish_accepted_qa_to_pool(question, answers_list, fusion)
            return question, score, it + 1
    return (question or "", score, max_iterations)