# Section 3.3 & 3.4: Adaptive Agentic Fusion Graph Collaborative Generation + Communication
# 3.3.1–3.3.4: agentic/agents.py
# 3.4: agentic/communication/protocol.py
# 3.3.4 Quality Assessment（G2S）：agentic/quality_assessment/graph2seq_runner.py
