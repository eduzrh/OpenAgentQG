"""
Neuro-symbolic graph construction.
API:
- build_fusion_graph(triples, entities, K_meta_sym, virtual_nodes)
- neuro_symbolic_fusion(sample)
"""
from config import FAST_MODE, ABLATION_MODE

from .meta_knowledge import meta_symbolic_aggregation, meta_neural_virtual_nodes


def build_fusion_graph(triples, entities, K_meta_sym, virtual_nodes):
    """
    Fusion graph G_fusion = (L_sym, H_neuro_sym).
    L_sym: list of meta-symbolic pattern strings.
    H_neuro_sym: hypergraph with entity nodes and hyperedges from virtual nodes.
    Return: dict with "meta_symbolic_layer" (list of str), "triples", "virtual_hyperedges" (list of {knowledge, nodes}).
    """
    if ABLATION_MODE == "no_graph_construction":
        L_sym = []
        hyperedges = []
    else:
        L_sym = [s.strip() for s in K_meta_sym.split(".") if s.strip()][:5]
        if not L_sym:
            L_sym = [K_meta_sym] if K_meta_sym else []
        hyperedges = [{"knowledge": v["knowledge"], "nodes": list(v["linked_entities"])} for v in virtual_nodes]
    return {
        "meta_symbolic_layer": L_sym,
        "triples": list(triples),
        "entities": set(entities),
        "virtual_hyperedges": hyperedges,
    }


def neuro_symbolic_fusion(sample):
    """
    Full Stage 1 for one sample: triples + entities -> fusion graph.
    FAST_MODE: meta_symbolic only, skip meta_neural (saves ~2 calls).
    """
    triples = sample["triples"]
    entities = sample["entities"]
    if not triples:
        return build_fusion_graph(triples, entities, "", [])

    K_meta_sym = meta_symbolic_aggregation(triples)
    if FAST_MODE:
        virtual_nodes = []
    else:
        virtual_nodes = meta_neural_virtual_nodes(triples, entities, K_meta_sym)
    return build_fusion_graph(triples, entities, K_meta_sym, virtual_nodes)


__all__ = [
    "build_fusion_graph",
    "neuro_symbolic_fusion",
]

