"""
Meta neuro-symbolic knowledge extraction.
API:
- meta_symbolic_aggregation(triples)
- meta_neural_virtual_nodes(triples, entities, K_meta_sym)
"""
import math

from llm_client import chat, chat_with_logprobs
from data_loader import triples_to_text
from config import ENTROPY_THRESHOLD, META_NEURAL_TOP_K, ABLATION_MODE


# --- Prompts (I_agg and parametric / augmented) ---
PROMPT_META_SYMBOLIC = """You are a knowledge abstraction expert. Given a set of knowledge graph triples (subject, relation, object), summarize them into 1-3 short ontological or conceptual patterns that capture the main facts (e.g. "Scientists are often born in countries; countries are located in continents."). Do not list the triples again; only output the abstract patterns.

Triples:
{triples}

Output (patterns only, no preamble):"""

PROMPT_PARAMETRIC_BASELINE = """Based only on the following entity names (no other context), list 1-2 plausible factual statements that might relate to them. One short sentence per line. Entity names: {entities}

Output:"""

PROMPT_PARAMETRIC_AUGMENTED = """Meta-symbolic knowledge (from a knowledge graph): {meta_sym}

Entity names: {entities}

List 1-2 plausible factual statements that are consistent with the meta-symbolic knowledge above and relate to the entities. One short sentence per line. Output only the statements:"""


def meta_symbolic_aggregation(triples):
    """K_meta_sym = LLM(G_sub, I_agg). Returns a string."""
    if ABLATION_MODE == "no_meta_knowledge":
        return ""
    text = triples_to_text(triples)
    prompt = PROMPT_META_SYMBOLIC.format(triples=text)
    out, _ = chat([{"role": "user", "content": prompt}], temperature=0.3)
    return out.strip()


def _entropy_from_logprobs(logprobs_list):
    """Approximate entropy from token logprobs: H = -sum p*log(p), p = exp(logprob)."""
    if not logprobs_list:
        return 0.0
    total = 0.0
    for tok_info in logprobs_list:
        if hasattr(tok_info, "top_logprobs") and tok_info.top_logprobs:
            probs = [math.exp(lp.logprob) for lp in tok_info.top_logprobs.values()]
            probs = [p for p in probs if 0 < p <= 1]
            if probs:
                z = sum(probs)
                for p in probs:
                    if p > 0:
                        total -= (p / z) * math.log(p / z + 1e-10)
    return total / max(len(logprobs_list), 1)


def meta_neural_virtual_nodes(triples, entities, K_meta_sym):
    """
    Generate K_param (no context), then K_aug (with K_meta_sym). If logprobs available,
    accept when delta_H <= tau. Otherwise accept when both outputs are non-empty.
    Returns: list of virtual node dicts: [{"knowledge": str, "linked_entities": set, "delta_H": float}]
    """
    if ABLATION_MODE == "no_meta_knowledge":
        return []
    entities_str = ", ".join(list(entities)[:15])
    # Baseline parametric
    prompt_base = PROMPT_PARAMETRIC_BASELINE.format(entities=entities_str)
    try:
        content_param, logprobs_param, _ = chat_with_logprobs([{"role": "user", "content": prompt_base}])
    except Exception:
        content_param, _ = chat([{"role": "user", "content": prompt_base}], temperature=0.0)
        logprobs_param = None
    H_param = _entropy_from_logprobs(getattr(logprobs_param, "content", []) if logprobs_param else [])

    # Context-augmented
    prompt_aug = PROMPT_PARAMETRIC_AUGMENTED.format(meta_sym=K_meta_sym, entities=entities_str)
    try:
        content_aug, logprobs_aug, _ = chat_with_logprobs([{"role": "user", "content": prompt_aug}])
    except Exception:
        content_aug, _ = chat([{"role": "user", "content": prompt_aug}], temperature=0.0)
        logprobs_aug = None
    H_aug = _entropy_from_logprobs(getattr(logprobs_aug, "content", []) if logprobs_aug else [])

    delta_H = H_aug - H_param
    # Accept if delta_H <= tau (symbolic reduces or maintains uncertainty) or if we have no logprobs
    if logprobs_param is None and logprobs_aug is None:
        use_param = content_param.strip() != ""
    else:
        use_param = delta_H <= ENTROPY_THRESHOLD

    virtual_nodes = []
    if use_param and content_param.strip():
        lines = [l.strip() for l in content_param.strip().split("\n") if l.strip()][:META_NEURAL_TOP_K]
        for line in lines:
            virtual_nodes.append({
                "knowledge": line,
                "linked_entities": set(entities),
                "delta_H": delta_H,
            })
    return virtual_nodes


__all__ = [
    "meta_symbolic_aggregation",
    "meta_neural_virtual_nodes",
]

