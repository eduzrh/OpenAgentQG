"""
Neuro-symbolic unified knowledge fusion for OpenAgentQG (Section 3.2).
Facade: 3.2.1 meta_knowledge, 3.2.2 graph_construction.
API:
- meta_symbolic_aggregation(triples)
- meta_neural_virtual_nodes(triples, entities, K_meta_sym)
- build_fusion_graph(triples, entities, K_meta_sym, virtual_nodes)
- neuro_symbolic_fusion(sample)
"""
from .meta_knowledge import meta_symbolic_aggregation, meta_neural_virtual_nodes
from .graph_construction import build_fusion_graph, neuro_symbolic_fusion

__all__ = [
    "meta_symbolic_aggregation",
    "meta_neural_virtual_nodes",
    "build_fusion_graph",
    "neuro_symbolic_fusion",
]
