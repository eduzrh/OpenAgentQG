# OpenAgentQG core: evaluation (BLEU/ROUGE) vendored for standalone run.
